#ifndef SSD1306_H
#define SSD1306_H

#include <stdint.h>
#include <stdbool.h>

bool ssd1306_init(void);
bool ssd1306_flush_page(uint8_t page);   /* sends one 128-byte page of g_fb */

#endif

/*
 * xfmt.h - small printf replacement and parsing helpers.
 *
 * Supported: %d %u %x %c %s %%, width, '-' and '0' flags, and
 *   %k  : fixed point from a value in thousandths. "%.2k" of 12345 -> "12.35"
 *         (use it for mV -> V, mA -> A, Hz -> kHz).
 * Integer arguments are read as int/unsigned (32-bit on both target and PC).
 */
#ifndef XFMT_H
#define XFMT_H

#include <stdint.h>
#include <stdbool.h>
#include <stddef.h>
#include <stdarg.h>

int  xvsnprintf(char *buf, size_t size, const char *fmt, va_list ap);
int  xsnprintf(char *buf, size_t size, const char *fmt, ...);

/* Parses "12", "12.5", "0.25" into an integer scaled by 10^decimals.
 * Trailing unit letters are ignored. Returns false on garbage. */
bool parse_fixed(const char *s, int decimals, int32_t *out);

uint32_t crc32_calc(const void *data, size_t len);

#endif

/*
 * board.h - pin map and low-level board control.
 *
 * Pin map (from netlist v2):
 *   PA0  ENC_A          TIM2_CH1, encoder (10k pull-up)
 *   PA1  ENC_B          TIM2_CH2, encoder (10k pull-up)
 *   PA2  ENC_SW         push button, active low (10k pull-up)
 *   PA4  UVLO           ADC12_IN4, VIN/14 (shared with LM5117 UVLO)
 *   PA5  ISENSE_ANALOG  ADC12_IN5, LM5117 CM output via 10k/10nF
 *   PA8  PWM_OUT        TIM1_CH1 -> UCC27511 IN+ (10k pull-down)
 *   PA9  UART_TX        USART1, J1 pin 2
 *   PA10 UART_RX        USART1, J1 pin 3
 *   PA12 FAULT_STOP     74HC latch reset, active low (10k pull-up), driven open-drain
 *   PA13 SWDIO / PA14 SWCLK (J2)
 *   PB0  LED_STATUS     blue,   active high
 *   PB10 LED_FAULT      red,    active high
 *   PB11 LED_CURLIM     yellow, active high
 *   PB6  I2C_SCL / PB7 I2C_SDA (4.7k pull-ups)
 *   PB12 FAULT_DETECT_IN  LM393 output, HIGH = over-current. Used as TIM1_BKIN.
 *   PB13 FAULT_DETECT_IN  (same net as PB12) - kept as an input, never driven
 *   PB14 BUCK_DIS       LM5117 VCCDIS, HIGH = buck off (10k pull-up)
 */
#ifndef BOARD_H
#define BOARD_H

#include <stdint.h>
#include <stdbool.h>
#include "stm32f1xx.h"

#define PA_ENC_A        0u
#define PA_ENC_B        1u
#define PA_ENC_SW       2u
#define PA_VIN_SENSE    4u
#define PA_ICM_SENSE    5u
#define PA_PWM          8u
#define PA_UART_TX      9u
#define PA_UART_RX      10u
#define PA_FAULT_STOP   12u

#define PB_LED_STATUS   0u
#define PB_I2C_SCL      6u
#define PB_I2C_SDA      7u
#define PB_LED_FAULT    10u
#define PB_LED_CURLIM   11u
#define PB_FAULT_DET    12u
#define PB_FAULT_DET2   13u
#define PB_BUCK_DIS     14u

#define ADC_CH_VIN      4u
#define ADC_CH_ICM      5u
#define ADC_CH_VREFINT  17u

/* GPIO CNF/MODE nibbles for the F1 CRL/CRH registers */
#define GPIO_ANALOG         0x0u
#define GPIO_IN_FLOAT       0x4u
#define GPIO_IN_PULL        0x8u   /* pull direction set by ODR */
#define GPIO_OUT_PP_2M      0x2u
#define GPIO_OUT_OD_2M      0x6u
#define GPIO_OUT_OD_10M     0x5u
#define GPIO_AF_PP_2M       0xAu
#define GPIO_AF_PP_50M      0xBu

typedef enum { LED_STATUS, LED_FAULT, LED_CURLIM } led_t;

void board_early_safe(void);   /* first thing after reset: buck held off */
void board_init(void);
void board_emergency_off(void);/* safe from any context, including fault handlers */
void gpio_cfg(GPIO_TypeDef *port, uint32_t pin, uint32_t cfg);

void led_set(led_t led, bool on);
void buck_enable(bool on);
bool buck_is_enabled(void);
bool fault_detect_active(void);   /* live comparator output, true = over-current */
void fault_latch_reset_pulse(void);

void iwdg_init(void);
void iwdg_kick(void);

#endif

#ifndef SOFT_I2C_H
#define SOFT_I2C_H

#include <stdint.h>
#include <stdbool.h>

/* Bit-banged I2C master on PB6/PB7. Avoids the STM32F1 hardware I2C
 * errata; supports clock stretching and recovers a stuck bus. */
void i2c_init(void);
void i2c_bus_recover(void);
bool i2c_probe(uint8_t addr);
bool i2c_write(uint8_t addr, const uint8_t *data, uint32_t len);
bool i2c_write_prefixed(uint8_t addr, uint8_t prefix, const uint8_t *data, uint32_t len);
bool i2c_read(uint8_t addr, uint8_t *data, uint32_t len);
bool i2c_write_read(uint8_t addr, const uint8_t *w, uint32_t wlen, uint8_t *r, uint32_t rlen);
uint32_t i2c_error_count(void);

#endif

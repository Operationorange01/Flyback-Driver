/*
 * gfx.h - 128x32 monochrome framebuffer with a 6x8 text grid
 * (21 columns x 4 lines). Pure C, no hardware access.
 */
#ifndef GFX_H_INCLUDED
#define GFX_H_INCLUDED

#include <stdint.h>

#define GFX_W      128
#define GFX_H      32
#define GFX_PAGES  (GFX_H / 8)
#define GFX_COLS   21
#define GFX_LINES  4

extern uint8_t g_fb[GFX_W * GFX_PAGES];

void gfx_clear(void);
void gfx_text(uint8_t col, uint8_t line, const char *s);
void gfx_printf(uint8_t line, const char *fmt, ...);
void gfx_invert_line(uint8_t line);

#endif

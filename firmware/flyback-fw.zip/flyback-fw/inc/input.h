#ifndef INPUT_H
#define INPUT_H

#include <stdint.h>
#include <stdbool.h>

typedef enum { BTN_NONE = 0, BTN_SHORT, BTN_LONG } btn_event_t;

void        input_init(void);
void        input_sample_1ms(void);          /* SysTick context */
int         input_enc_steps(bool *fast);     /* detents since last call, signed */
btn_event_t input_take_button(void);

#endif

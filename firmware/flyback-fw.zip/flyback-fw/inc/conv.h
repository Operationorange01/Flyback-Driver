/*
 * conv.h - pure unit conversions between physical values and register
 * codes. No hardware access, so the same file builds on a PC for tests.
 */
#ifndef CONV_H
#define CONV_H

#include <stdint.h>

/* PRIMARY_RAIL setpoint <-> U3 DAC code (inverse relationship) */
uint16_t conv_vout_to_code(int32_t vout_mv, int32_t vdd_mv);
int32_t  conv_code_to_vout(uint16_t code, int32_t vdd_mv);

/* Hardware OCP threshold <-> U10 DAC code */
uint16_t conv_trip_to_code(int32_t i_ma, int32_t vdd_mv);
int32_t  conv_code_to_trip(uint16_t code, int32_t vdd_mv);

/* ADC conversions (12-bit raw) */
int32_t  conv_adc_to_mv(uint32_t raw, int32_t vdd_mv);
int32_t  conv_vin_from_pin(int32_t pin_mv);       /* PA4 -> VIN_PROT */
int32_t  conv_icm_from_pin(int32_t pin_mv);       /* PA5 -> LM5117 output current, mA */
int32_t  conv_vdd_from_vrefint(uint32_t raw);

/* INA226 raw registers */
int32_t  conv_ina_shunt_to_ma(int16_t raw);
int32_t  conv_ina_bus_to_mv(uint16_t raw);

/* TIM1 timing for a given frequency and duty (duty in 0.1 %) */
typedef struct { uint32_t psc, arr, ccr; } pwm_timing_t;
pwm_timing_t conv_pwm_timing(uint32_t timer_clk, uint32_t freq_hz, uint32_t duty_x10, uint32_t duty_max_x10);

#endif

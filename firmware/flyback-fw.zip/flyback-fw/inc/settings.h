#ifndef SETTINGS_H
#define SETTINGS_H

#include <stdint.h>
#include <stdbool.h>

typedef struct {
    uint32_t freq_hz;
    uint16_t duty_x10;    /* 0.1 % units */
    uint16_t vset_mv;
    uint16_t ilim_ma;
    uint16_t trip_ma;
    uint16_t ss_ms;
    uint16_t reserved;
} settings_t;

extern settings_t g_set;

void settings_defaults(void);
bool settings_load(void);    /* false -> defaults were used */
bool settings_save(void);
void settings_clamp(void);

#endif

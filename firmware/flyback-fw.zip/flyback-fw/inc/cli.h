#ifndef CLI_H
#define CLI_H

#include <stdint.h>

void cli_init(void);
void cli_poll(void);            /* read characters, run complete lines */
void cli_tick(uint32_t now);    /* telemetry stream */

#endif

#ifndef CONTROL_H
#define CONTROL_H

#include <stdint.h>
#include <stdbool.h>

typedef enum { ST_OFF = 0, ST_STARTING, ST_RUN, ST_FAULT } ctrl_state_t;

typedef enum {
    FLT_NONE = 0,
    FLT_HW_OCP,     /* comparator tripped the hardware latch */
    FLT_OVP,        /* primary rail above limit */
    FLT_COMM,       /* lost the INA226 or a DAC */
    FLT_CC,         /* current over limit even at minimum rail voltage */
    FLT_BOOT,       /* a required I2C device was missing at power-up */
} fault_t;

typedef struct {
    ctrl_state_t state;
    fault_t      fault;
    /* measurements */
    bool     ina_valid;
    int32_t  vbus_mv, i_ma, p_mw;
    int32_t  vin_mv, icm_ma, vdd_mv;
    /* what the controller is doing */
    int32_t  vcmd_mv;          /* rail command after soft-start, CC limit, slew */
    int32_t  vtrim_mv;
    uint32_t duty_now_x10;
    bool     cc_active;
    uint16_t dac_vset_code, dac_trip_code;
    /* devices present */
    bool     dev_ina, dev_dac_v, dev_dac_t;
    uint32_t trip_count;
} ctrl_status_t;

extern ctrl_status_t g_st;

void        control_init(void);
void        control_tick(void);              /* every CTRL_PERIOD_MS */
const char *control_start(void);             /* NULL on success, else reason */
void        control_stop(void);
bool        control_clear_fault(void);
bool        control_apply_trip(void);        /* after g_set.trip_ma changes */
const char *control_state_name(ctrl_state_t s);
const char *control_fault_name(fault_t f);
bool        control_active(void);

#endif

#ifndef UI_H
#define UI_H

#include <stdint.h>
#include <stdbool.h>
#include "input.h"

void ui_init(bool oled_present);
void ui_tick(uint32_t now);                       /* main loop: input, render, flush */
void ui_handle(int steps, bool fast, btn_event_t ev, uint32_t now);
void ui_render(uint32_t now);                     /* draws into g_fb */
void ui_message(const char *msg, uint32_t now);

#endif

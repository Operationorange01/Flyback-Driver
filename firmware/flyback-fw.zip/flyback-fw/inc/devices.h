/*
 * devices.h - drivers for the I2C parts: MCP4725 DACs, INA226 monitor.
 */
#ifndef DEVICES_H
#define DEVICES_H

#include <stdint.h>
#include <stdbool.h>

/* MCP4725 */
bool mcp4725_write(uint8_t addr, uint16_t code);                 /* fast write, volatile */
bool mcp4725_write_eeprom(uint8_t addr, uint16_t code);          /* DAC + EEPROM, ~50 ms */
bool mcp4725_read(uint8_t addr, uint16_t *dac, uint16_t *eeprom);

/* INA226 */
typedef struct {
    int32_t vbus_mv;
    int32_t i_ma;
    int32_t p_mw;
} ina226_sample_t;

bool ina226_init(void);
/* Returns false on a bus error. *fresh = true when a new conversion was read. */
bool ina226_poll(ina226_sample_t *s, bool *fresh);

#endif

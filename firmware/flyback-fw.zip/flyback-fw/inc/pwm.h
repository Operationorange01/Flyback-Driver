#ifndef PWM_H
#define PWM_H

#include <stdint.h>
#include <stdbool.h>

void     pwm_init(void);
void     pwm_set(uint32_t freq_hz, uint32_t duty_x10);
bool     pwm_arm(void);        /* false if the break input is still active */
void     pwm_disarm(void);
bool     pwm_is_armed(void);
uint32_t pwm_actual_freq(void);

/* Implemented in control.c, called from the break interrupt */
void control_hw_trip_isr(void);

#endif

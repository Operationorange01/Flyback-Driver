#ifndef UART_H
#define UART_H

#include <stdint.h>
#include <stdbool.h>

void uart_init(uint32_t baud);
void uart_putc(char c);
void uart_puts(const char *s);
void uart_printf(const char *fmt, ...);
int  uart_getc(void);            /* -1 if nothing received */
void uart_flush(void);           /* wait until the TX buffer has drained */

#endif

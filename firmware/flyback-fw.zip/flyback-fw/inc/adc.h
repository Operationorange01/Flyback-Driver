#ifndef ADC_H
#define ADC_H

#include <stdint.h>

typedef struct {
    int32_t vdd_mv;      /* measured from the internal reference */
    int32_t vin_mv;      /* input after reverse-polarity FET (VIN_PROT) */
    int32_t icm_ma;      /* LM5117 current monitor (CCM only, approximate) */
    int32_t uvlo_pin_mv;
} adc_values_t;

void adc_init(void);
void adc_update(adc_values_t *v);

#endif

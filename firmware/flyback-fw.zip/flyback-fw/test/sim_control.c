/*
 * Closed-loop simulation of control.c (the real file, unmodified) against
 * a simple plant:
 *   - LM5117 rail follows the U3 DAC command through a first-order lag,
 *     with a deliberate +2.5 % gain error so the trim loop has work to do
 *   - flyback in DCM: average primary current I = V * D^2 / (2 L f)
 *   - INA226 delivers a new sample every 35 ms
 * Scenarios exercise soft start, CC limiting, OVP, hardware trip,
 * sensor loss and an un-limitable short.
 */
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <math.h>
#include "stm32f1xx.h"
#include "control.h"
#include "settings.h"
#include "config.h"
#include "conv.h"
#include "devices.h"
#include "adc.h"
#include "pwm.h"
#include "board.h"

TIM_TypeDef fake_tim1;
settings_t g_set;

/* ---- simulated hardware ---- */
static uint32_t sim_ms;
static double   rail_v;            /* actual PRIMARY_RAIL */
static uint16_t dac_code = 4095;
static bool     buck_on, pwm_on;
static uint32_t pwm_duty;
static double   L_uH = 60.0;
static bool     ina_dead, rail_stuck_high, load_short, comparator_high;
static int      ina_div;
static bool     led[3];

uint32_t millis(void) { return sim_ms; }
void delay_us(uint32_t us) { (void)us; }
void delay_ms(uint32_t ms) { (void)ms; }
void led_set(led_t l, bool on) { led[l] = on; }
void buck_enable(bool on) { buck_on = on; }
bool buck_is_enabled(void) { return buck_on; }
bool fault_detect_active(void) { return comparator_high; }
void fault_latch_reset_pulse(void) { }
void uart_printf(const char *fmt, ...) { (void)fmt; }
void uart_puts(const char *s) { (void)s; }

bool mcp4725_write(uint8_t a, uint16_t c) { if (a == I2C_ADDR_DAC_VSET) dac_code = c; return true; }
bool mcp4725_write_eeprom(uint8_t a, uint16_t c) { (void)a; (void)c; return true; }
bool mcp4725_read(uint8_t a, uint16_t *d, uint16_t *e) { (void)a; if (d) *d = 0; if (e) *e = 4095; return true; }
bool ina226_init(void) { return true; }

static double load_current(void)
{
    if (!buck_on) return 0;
    if (load_short) return 3.0;
    double d = pwm_on ? pwm_duty / 1000.0 : 0.0;
    return rail_v * d * d / (2.0 * L_uH * 1e-6 * g_set.freq_hz);
}

bool ina226_poll(ina226_sample_t *s, bool *fresh)
{
    *fresh = false;
    if (ina_dead) return false;
    if (++ina_div < 7) return true;
    ina_div = 0;
    s->vbus_mv = (int32_t)(rail_v * 1000);
    s->i_ma    = (int32_t)(load_current() * 1000);
    s->p_mw    = (int32_t)(rail_v * load_current() * 1000);
    *fresh = true;
    return true;
}

void adc_update(adc_values_t *v) { v->vdd_mv = 3200; v->vin_mv = 30000; v->icm_ma = 0; v->uvlo_pin_mv = 2100; }
void pwm_set(uint32_t f, uint32_t d) { (void)f; pwm_duty = d > DUTY_MAX_X10 ? DUTY_MAX_X10 : d; }
bool pwm_arm(void) { pwm_on = true; return true; }
void pwm_disarm(void) { pwm_on = false; pwm_duty = 0; }
bool pwm_is_armed(void) { return pwm_on; }
void settings_clamp(void) { }

static void plant_step(double dt)
{
    double target = 0;
    if (buck_on) target = conv_code_to_vout(dac_code, 3200) / 1000.0 * 1.025;   /* 2.5 % error */
    if (rail_stuck_high) target = 27.5;
    rail_v += (target - rail_v) * (dt / 0.010);   /* tau = 10 ms */
    if (rail_v < 0) rail_v = 0;
}

static FILE *csv;
static void run_ms(uint32_t ms)
{
    for (uint32_t t = 0; t < ms; t += CTRL_PERIOD_MS) {
        sim_ms += CTRL_PERIOD_MS;
        plant_step(CTRL_PERIOD_MS / 1000.0);
        control_tick();
        fprintf(csv, "%u,%d,%d,%.4f,%.4f,%.2f,%.4f,%d,%d,%d\n", sim_ms, g_st.state, g_st.fault,
                rail_v, g_st.vcmd_mv / 1000.0, pwm_duty / 10.0, load_current(), g_st.cc_active,
                g_st.vtrim_mv, g_set.ilim_ma);
    }
}

static int fails;
#define EXPECT(c, ...) do { if (!(c)) { fails++; printf("  FAIL: "); printf(__VA_ARGS__); printf("\n"); } else { printf("  ok:   "); printf(__VA_ARGS__); printf("\n"); } } while (0)

int main(int argc, char **argv)
{
    csv = fopen(argc > 1 ? argv[1] : "sim.csv", "w");
    fprintf(csv, "t_ms,state,fault,rail_v,vcmd_v,duty_pct,i_a,cc,trim_mv,ilim_ma\n");

    g_set = (settings_t){ .freq_hz = 20000, .duty_x10 = 300, .vset_mv = 18000,
                          .ilim_ma = 2000, .trip_ma = 2500, .ss_ms = 1000 };
    control_init();
    printf("boot: state %s fault %s\n", control_state_name(g_st.state), control_fault_name(g_st.fault));
    EXPECT(g_st.state == ST_OFF && !buck_on && !pwm_on, "boots OFF with buck and PWM disabled");

    run_ms(200);
    printf("[1] soft start to 18 V, 30 %% duty, 1 s ramp\n");
    EXPECT(control_start() == NULL, "start accepted");
    run_ms(500);
    EXPECT(g_st.state == ST_STARTING && pwm_duty > 100 && pwm_duty < 200, "half way: duty %.1f%%", pwm_duty / 10.0);
    run_ms(1500);
    EXPECT(g_st.state == ST_RUN, "reached RUN");
    run_ms(3000);
    EXPECT(fabs(rail_v - 18.0) < 0.03, "trim corrects 2.5%% plant error: rail %.3f V (trim %d mV)", rail_v, g_st.vtrim_mv);
    EXPECT(!g_st.cc_active, "CC inactive at %.3f A", load_current());

    printf("[2] current limit lowered to 0.5 A\n");
    g_set.ilim_ma = 500;
    run_ms(3000);
    EXPECT(g_st.cc_active && led[LED_CURLIM], "CC active, LED on");
    EXPECT(fabs(load_current() - 0.5) < 0.06, "current held at %.3f A (rail %.2f V)", load_current(), rail_v);
    g_set.ilim_ma = 2000;
    run_ms(3000);
    EXPECT(!g_st.cc_active && fabs(rail_v - 18.0) < 0.05, "recovers to 18 V when limit raised (%.3f V)", rail_v);

    printf("[3] hardware over-current trip\n");
    control_hw_trip_isr();
    run_ms(20);
    EXPECT(g_st.state == ST_FAULT && g_st.fault == FLT_HW_OCP && !buck_on && !pwm_on, "latched OCP fault, outputs off");
    EXPECT(control_start() != NULL, "restart refused while faulted");
    comparator_high = true;
    EXPECT(!control_clear_fault(), "clear refused while comparator still high");
    comparator_high = false;
    EXPECT(control_clear_fault() && g_st.state == ST_OFF, "clear works once comparator is low");

    printf("[4] over-voltage (rail runs away)\n");
    run_ms(500);
    control_start();
    run_ms(2500);
    rail_stuck_high = true;
    run_ms(200);
    EXPECT(g_st.state == ST_FAULT && g_st.fault == FLT_OVP, "OVP fault (rail %.2f V)", rail_v);
    rail_stuck_high = false;
    run_ms(500);
    control_clear_fault();

    printf("[5] INA226 stops answering while running\n");
    control_start();
    run_ms(1500);
    ina_dead = true;
    run_ms(400);
    EXPECT(g_st.state == ST_FAULT && g_st.fault == FLT_COMM, "sensor timeout -> I2C fault");
    ina_dead = false;
    control_clear_fault();

    printf("[6] short that CC cannot limit\n");
    run_ms(300);
    g_set.ilim_ma = 1000;
    control_start();
    run_ms(500);
    load_short = true;
    run_ms(2000);
    EXPECT(g_st.state == ST_FAULT && g_st.fault == FLT_CC, "CLIM fault after rail hits minimum");
    load_short = false;

    fclose(csv);
    printf("%s (%d failures)\n", fails ? "SIMULATION FAILED" : "ALL CONTROL SCENARIOS PASSED", fails);
    return fails != 0;
}

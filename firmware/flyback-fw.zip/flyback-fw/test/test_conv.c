/* Host unit tests for conv.c and xfmt.c */
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include "conv.h"
#include "xfmt.h"
#include "config.h"

static int fails;
#define CHECK(cond, ...) do { if (!(cond)) { fails++; printf("FAIL %s:%d: ", __FILE__, __LINE__); printf(__VA_ARGS__); printf("\n"); } } while (0)

static void check_fmt(const char *expect, const char *fmt, int v)
{
    char b[32];
    xsnprintf(b, sizeof b, fmt, v);
    CHECK(!strcmp(b, expect), "fmt '%s' %d -> '%s' (want '%s')", fmt, v, b, expect);
}

int main(void)
{
    /* Rail setpoint network: hardware range at VDD = 3.2 V */
    int32_t vmax = conv_code_to_vout(0, 3200), vmin = conv_code_to_vout(4095, 3200);
    printf("rail range: %.3f V (code 4095) .. %.3f V (code 0)\n", vmin / 1000.0, vmax / 1000.0);
    printf("rail resolution: %.2f mV/LSB\n", (conv_code_to_vout(2000, 3200) - conv_code_to_vout(2001, 3200)) * 1.0);
    CHECK(vmin < VSET_MIN_MV && vmax > VSET_MAX_MV, "limits outside hardware range");

    /* Round-trip every 10 mV across the user range: error < 1 LSB (~4.5 mV) */
    int worst = 0;
    for (int mv = VSET_MIN_MV; mv <= VSET_MAX_MV; mv += 10) {
        int e = abs(conv_code_to_vout(conv_vout_to_code(mv, 3200), 3200) - mv);
        if (e > worst) worst = e;
    }
    printf("vset round-trip worst error: %d mV\n", worst);
    CHECK(worst <= 3, "vset round trip error %d", worst);
    CHECK(conv_vout_to_code(VSET_MIN_MV, 3200) > conv_vout_to_code(VSET_MAX_MV, 3200), "should be inverse");

    /* Hand calculation: 12 V -> Vdac = 0.8 - 17.4k*((11.2/100k) - 0.8/4.12k) = 2.2299 V */
    int c12 = conv_vout_to_code(12000, 3200);
    printf("12 V -> code %d (expect ~2854)\n", c12);
    CHECK(abs(c12 - 2854) <= 1, "12V code %d", c12);

    /* OCP trip */
    printf("trip range: %.3f A max (code 4095)\n", conv_code_to_trip(4095, 3200) / 1000.0);
    CHECK(conv_code_to_trip(4095, 3200) > TRIP_MAX_MA, "trip max out of DAC range");
    int c2 = conv_trip_to_code(2000, 3200);
    printf("2.0 A trip -> code %d, back %d mA, comparator ref %.2f mV\n", c2,
           conv_code_to_trip(c2, 3200), 2.0 * 0.033 * 1000);
    CHECK(abs(conv_code_to_trip(c2, 3200) - 2000) <= 2, "trip round trip");

    /* VIN sense */
    CHECK(abs(conv_vin_from_pin(1000) - 14000) <= 1, "vin below threshold");
    CHECK(abs(conv_vin_from_pin(2000) - 25400) <= 1, "vin with hysteresis current %d", conv_vin_from_pin(2000));

    /* INA226 */
    CHECK(conv_ina_bus_to_mv(9600) == 12000, "bus");
    CHECK(conv_ina_shunt_to_ma(13200) == 1000, "shunt 13200 -> %d", conv_ina_shunt_to_ma(13200));
    CHECK(conv_ina_shunt_to_ma(-132) == -10, "neg shunt");

    /* PWM timing at 64 MHz */
    struct { uint32_t f, d; } cases[] = { {500,100}, {1000,500}, {20000,100}, {20000,500}, {65000,333}, {150000,250}, {150000,900} };
    for (unsigned i = 0; i < sizeof cases / sizeof cases[0]; i++) {
        pwm_timing_t t = conv_pwm_timing(SYSCLK_HZ, cases[i].f, cases[i].d, DUTY_MAX_X10);
        double fa = (double)SYSCLK_HZ / ((t.psc + 1.0) * (t.arr + 1.0));
        double da = 100.0 * t.ccr / (t.arr + 1.0);
        printf("  %6u Hz %5.1f%% -> PSC %u ARR %5u CCR %5u : %9.1f Hz %5.2f%%\n",
               cases[i].f, cases[i].d / 10.0, t.psc, t.arr, t.ccr, fa, da);
        CHECK(t.arr <= 65535 && t.psc <= 65535, "register overflow");
        CHECK(fa > cases[i].f * 0.995 && fa < cases[i].f * 1.005, "freq error");
        CHECK(da <= DUTY_MAX_X10 / 10.0 + 1e-9, "duty ceiling broken");
    }

    /* Formatter */
    check_fmt("12.35", "%.2k", 12345);
    check_fmt("0.512", "%.3k", 512);
    check_fmt("-0.05", "%.2k", -50);
    check_fmt("0.00", "%.2k", -4);
    check_fmt(" 12.03", "%6.2k", 12030);
    check_fmt("20.00", "%.2k", 20000);
    check_fmt("150.0", "%.1k", 150000);
    check_fmt("10.0", "%.1k", 10000);
    check_fmt("-42", "%d", -42);
    check_fmt("ff", "%x", 255);
    check_fmt("007", "%03d", 7);

    /* Parser */
    int32_t v;
    CHECK(parse_fixed("12.5", 3, &v) && v == 12500, "12.5");
    CHECK(parse_fixed("18", 3, &v) && v == 18000, "18");
    CHECK(parse_fixed("0.25A", 3, &v) && v == 250, "0.25A");
    CHECK(parse_fixed("25k", 3, &v) && v == 25000, "25k");
    CHECK(parse_fixed("12.5", 1, &v) && v == 125, "duty");
    CHECK(!parse_fixed("abc", 3, &v), "garbage");
    CHECK(!parse_fixed("1x2", 3, &v), "garbage2");

    printf("%s (%d failures)\n", fails ? "FAILED" : "ALL CONVERSION TESTS PASSED", fails);
    return fails != 0;
}

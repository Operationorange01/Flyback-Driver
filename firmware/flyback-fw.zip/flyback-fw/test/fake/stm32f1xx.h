/* Minimal stand-in for the CMSIS device header so control.c builds on a PC */
#ifndef FAKE_STM32F1XX_H
#define FAKE_STM32F1XX_H
#include <stdint.h>

typedef struct { volatile uint32_t SR, DIER, BDTR; } TIM_TypeDef;
typedef struct { volatile uint32_t CRL, CRH, IDR, ODR, BSRR, BRR; } GPIO_TypeDef;
extern TIM_TypeDef fake_tim1;
#define TIM1 (&fake_tim1)
#define TIM_SR_BIF   (1u << 7)
#define TIM_DIER_BIE (1u << 7)
#define TIM_BDTR_MOE (1u << 15)

#endif

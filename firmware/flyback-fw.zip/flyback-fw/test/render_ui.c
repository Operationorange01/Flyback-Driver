/* Renders OLED screens with the real ui.c/gfx.c into PBM images */
#include <stdio.h>
#include <string.h>
#include "gfx.h"
#include "ui.h"
#include "control.h"
#include "settings.h"
#include "config.h"

settings_t g_set;
ctrl_status_t g_st;

const char *control_start(void) { return NULL; }
void control_stop(void) { }
bool control_clear_fault(void) { return true; }
bool control_apply_trip(void) { return true; }
bool control_active(void) { return g_st.state == ST_STARTING || g_st.state == ST_RUN; }
const char *control_state_name(ctrl_state_t s) { static const char *n[] = { "OFF", "SOFT", "RUN", "FAULT" }; return n[s]; }
const char *control_fault_name(fault_t f) { static const char *n[] = { "none", "OCP", "OVP", "I2C", "CLIM", "BOOT" }; return n[f]; }
bool settings_save(void) { return true; }
bool ssd1306_init(void) { return false; }
bool ssd1306_flush_page(uint8_t p) { (void)p; return true; }
int input_enc_steps(bool *fast) { *fast = false; return 0; }
btn_event_t input_take_button(void) { return BTN_NONE; }
uint32_t millis(void) { return 0; }

static void dump(const char *name)
{
    FILE *f = fopen(name, "w");
    fprintf(f, "P1\n%d %d\n", GFX_W, GFX_H);
    for (int y = 0; y < GFX_H; y++) {
        for (int x = 0; x < GFX_W; x++)
            fprintf(f, "%d ", (g_fb[(y / 8) * GFX_W + x] >> (y % 8)) & 1);
        fprintf(f, "\n");
    }
    fclose(f);
}

int main(void)
{
    g_set = (settings_t){ .freq_hz = 20000, .duty_x10 = 100, .vset_mv = 12000,
                          .ilim_ma = 1000, .trip_ma = 2000, .ss_ms = 1000 };
    ui_init(false);

    /* 1: running, browsing Vset */
    g_st = (ctrl_status_t){ .state = ST_RUN, .ina_valid = true, .vbus_mv = 12030, .i_ma = 512,
                            .p_mw = 6159, .vin_mv = 30100, .duty_now_x10 = 100 };
    ui_render(0);
    dump("screen_run.pbm");

    /* 2: CC mode, editing frequency (one press, then 3 steps up) */
    g_set.freq_hz = 125000;
    g_st.cc_active = true; g_st.vbus_mv = 8410; g_st.i_ma = 1000; g_st.p_mw = 8410;
    ui_handle(1, false, BTN_NONE, 1);
    ui_handle(0, false, BTN_SHORT, 2);
    ui_render(3);
    dump("screen_cc_edit.pbm");

    /* 3: latched fault */
    ui_handle(0, false, BTN_SHORT, 4);
    g_st = (ctrl_status_t){ .state = ST_FAULT, .fault = FLT_HW_OCP, .ina_valid = true,
                            .vbus_mv = 0, .i_ma = 0, .vin_mv = 29800 };
    ui_render(5);
    dump("screen_fault.pbm");

    /* 4: off, no INA226 data, message on bottom line */
    g_st = (ctrl_status_t){ .state = ST_OFF, .ina_valid = false, .vin_mv = 14200 };
    ui_message("Settings saved", 6);
    ui_render(7);
    dump("screen_off_msg.pbm");
    printf("rendered 4 screens\n");
    return 0;
}

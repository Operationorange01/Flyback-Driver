# Flyback Driver firmware

Bare-metal C firmware for the STM32F103C8T6 on the Flyback Driver board (netlist v2). No HAL, no RTOS: CMSIS register headers only, ~18 KB flash, ~4 KB RAM.

![OLED screens](docs/oled_screens.png)

## What it does

| Feature | How |
|---|---|
| Variable frequency, 500 Hz to 150 kHz | TIM1 CH1 on PA8, prescaler picked automatically; PSC/ARR/CCR change together on the next period, so there are no runt pulses |
| Variable duty, 0 to 50 % | 0.1 % steps; 50 % is a hard ceiling in `config.h` and in the timing code |
| Primary rail 6.5 to 24.5 V | U3 MCP4725 into the LM5117 FB node, ~4.5 mV per DAC step |
| Voltage regulation | LM5117 does the fast loop; firmware trims the DAC so the INA226 reading matches the setpoint (absorbs resistor and 3V3 tolerances) |
| Current regulation (CC) | when INA226 average current exceeds `I limit`, firmware lowers the rail; yellow LED on |
| Soft start | duty and rail ramp together over `Softstart` (default 1 s); also slew limits on every later change |
| Hardware over-current | LM393 + 74HC latch block the gate driver; the same comparator output is TIM1_BKIN, which clears the timer outputs without the CPU; firmware then latches a fault |
| Adjustable trip threshold | U10 MCP4725, 0.1 to 2.8 A peak switch current |
| Latching faults | OCP, over-voltage, lost I2C sensor, current limit unable to hold; cleared only by a long press or `clear` |
| OLED, encoder, LEDs | see below |
| Serial console + CSV logging | J1, 115200 8N1 |
| Settings saved in flash | last 1 KB page; output always boots OFF |
| Watchdog | ~0.5 s IWDG; any CPU fault turns the power stage off |

## Build and flash

Needs `arm-none-eabi-gcc` and `make`. The CMSIS headers are already in `Drivers/`.

```
make                 # -> build/flyback.elf / .bin / .hex
make flash           # ST-Link with stlink tools (st-flash)
make flash-openocd   # or OpenOCD
make test            # PC-side tests (needs normal gcc)
```

SWD is on J2: 1 = 3V3, 2 = SWDIO, 3 = SWCLK, 4 = NRST, 5 = GND.
Serial is on J1: 2 = TX (board out), 3 = RX (board in), 4/8 = GND. J1 6/7 also bring out SCL/SDA.

STM32CubeIDE also works: make an empty STM32F103C8 project, drop in `src/`, `inc/`, the linker script, and define `STM32F103xB`.

## Controls

```
RUN  20.00kHz D10.0%      state, frequency, duty
Vp 12.03V  I 0.512A       primary rail and average primary current (INA226)
P  6.16W  Vin 30.1V       power, input voltage
> Vset       12.00 V      menu item (inverted while editing)
```

- **Turn**: scroll the menu, or change the value while editing (spin fast for x10 steps)
- **Short press**: start/stop editing the item; on `Save` it saves to flash
- **Long press (0.8 s)**: output ON/OFF. In a fault, long press clears it

Menu: Vset, Freq, Duty, I limit, OCP trip, Softstart, Save. Changes apply live, also while running.

State field: `OFF`, `SOFT` (ramping), `RUN`, `CC` (current limit active), `UVLO` (VIN below ~17.5 V, the LM5117 won't switch), or `FAULT:xxx`.

LEDs: blue = running (fast blink while soft starting), red = latched fault (slow blink = an I2C chip was missing at power-up), yellow = current limit active.

## Serial commands

```
on | off | clear | status | get
vset 18.5     freq 25k     duty 12.5     ilim 1.2     trip 2.5     ss 1500
save | load | defaults
stream 100    CSV telemetry every 100 ms (stream 0 to stop)
i2cscan       expect 0x3c OLED, 0x40 INA226, 0x60 and 0x61 DACs
```

`stream` columns: `t_ms,state,fault,freq_hz,duty_pct,vset_v,vcmd_v,vbus_v,i_a,p_w,vin_v,icm_a,cc,trips`. Capture it with any serial logger and you have a run log for the experiment.

## Faults

| Name | Cause | Notes |
|---|---|---|
| `OCP` | comparator saw switch current above the trip setting | gate already blocked in hardware before firmware sees it; also turns the buck off (`TRIP_DISABLES_BUCK`) |
| `OVP` | rail > 27 V, or > 3 V above command for ~350 ms | |
| `I2C` | no INA226 data for 300 ms, or a DAC stopped answering, while running | the firmware refuses to run blind |
| `CLIM` | current still >110 % of the limit with the rail already at minimum | e.g. a hard short or arc on the secondary |
| `BOOT` | INA226 or a DAC missing at power-up | `clear` re-probes |

Clearing a fault only works once the comparator output is low again. It pulses FAULT_STOP to reset the 74HC latch and re-checks the TIM1 break flag.

## First power-up

1. Flash with no input supply, just ST-Link power. Open the serial console: you should see the boot banner and `INA226 ok, DAC Vset ok, DAC trip ok, OCP latch clear`. The OLED is optional and is picked up if plugged in later.
2. On first boot the firmware writes U3's EEPROM so its power-on output is the *lowest* rail voltage. This happens once.
3. Apply VIN (above 17.5 V) with **no transformer connected**, `duty 0`, `vset 8`, `on`. Measure PRIMARY_RAIL (TP3) with a meter; it should read 8 V and `status` should agree. Step `vset` up and check that both still agree.
4. Check the trip path at low voltage: with a small resistive load across J4 and a low `trip` setting, increase duty until it trips. The red LED and `FAULT:OCP` should appear and TP9 (gate) should stay low.
5. Only then connect the flyback and start from low duty and low rail.

Don't halt the debugger with high voltage live. TIM1 is configured to force its output off when the core halts, but the control loop and protections in firmware stop too.

## Configuration

Everything is in `inc/config.h`: hardware resistor values, limits, defaults, control gains, encoder resolution.

- If one encoder click moves two steps, set `ENC_COUNTS_PER_DETENT` to 4. If clockwise turns values down, set `ENC_REVERSE` to 1.
- `DUTY_MAX_X10` (50.0 %) is the core-reset safety margin. Raise it only if your transformer design allows it.
- `CC_GAIN_MV_PER_MA` and `CC_RECOVER_MV` set how hard and how fast the current limit acts.

## Tests

`make test` builds three programs with the PC compiler:

- `test_conv`: DAC/rail/trip math against hand calculations, PWM timing at the frequency extremes, the formatter and parser
- `sim_control`: the real `control.c` against a model of the LM5117 rail (with a deliberate 2.5 % gain error) and a DCM flyback load. Scenarios: soft start, CC limiting and recovery, hardware trip and clearing, OVP, sensor loss, a short that CC cannot hold
- `render_ui`: renders OLED screens with the real `ui.c` to images (that's where the picture above comes from)

## Hardware notes from the netlist

Things the firmware works around, or that are worth knowing:

1. **PB12 and PB13 are both on FAULT_DETECT_IN.** PB12 is used as TIM1_BKIN. PB13 is held as an input; driving it low would mask a real trip. Consider removing that connection.
2. **The latch output (GATE_STOP) isn't connected to the MCU,** so the firmware can't confirm the latch actually reset. Routing it to a free pin (PB15 is free) would allow a check.
3. **The "3.3V" rail is 3.20 V** (TPS62130 with R33 = 300k, R34 = 100k). Fine for every part; the DAC math uses 3.20 V.
4. **R12 is 4.07k in the schematic and 4.12k in the BOM.** Firmware uses 4.12k; the trim loop absorbs the difference either way.
5. **The LM5117 needs VIN above ~17.5 V to start** (R17/R18 UVLO divider). For a 24.5 V rail you need roughly 27 V or more in, and D2 (SMCJ33A) limits you to ~33 V.
6. **The OCP comparator output is HIGH on over-current** (current on the + input). Firmware assumes that polarity.
7. **The INA226 shunt range ends at 2.48 A.** It measures the pulsed switch current; if peaks go above that, the average it reports will read low. The CC limit is capped at 2.4 A for that reason.
8. **U11 is a 74HC00 in the schematic and a 74HC132 in the BOM.** Same pinout, either works as the latch.
9. **BOM vs netlist mismatches:** R23 is "10k, 5W" in the schematic but "100k, 2W" in the BOM; D6 (1N4742A) is in the BOM but not in the netlist.
10. **No crystal**, so the MCU runs from the internal oscillator at 64 MHz (±1 % frequency accuracy).

## Layout

```
src/   startup, clock, board pins, pwm (TIM1 + break), soft_i2c, devices (MCP4725, INA226),
       ssd1306 + gfx, input (encoder/button), uart, adc, settings, control, ui, cli, main
inc/   headers, config.h
linker/stm32f103c8.ld
Drivers/CMSIS   ARM and ST headers (Apache-2.0)
test/  host-side tests
```
